/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usbpd_pdo_defs.h
  * @author  MCD Application Team
  * @brief   Header file for definition of PDO/APDO values for 2 ports(DRP/SNK) configuration
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef __USBPD_PDO_DEF_H
#define __USBPD_PDO_DEF_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "usbpd_def.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Define   ------------------------------------------------------------------*/
#define PORT0_NB_SOURCEPDO         0U   /* Number of Source PDOs (applicable for port 0)   */
#define PORT0_NB_SINKPDO           7U   /* Number of Sink PDOs (applicable for port 0)     */
#define PORT1_NB_SOURCEPDO         0U   /* Number of Source PDOs (applicable for port 1)   */
#define PORT1_NB_SINKPDO           0U   /* Number of Sink PDOs (applicable for port 1)     */

/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Exported typedef ----------------------------------------------------------*/

/* USER CODE BEGIN typedef */

/**
  * @brief  USBPD Port PDO Structure definition
  *
  */
/* USER CODE END typedef */

/* Exported define -----------------------------------------------------------*/

/* USER CODE BEGIN Exported_Define */

#define USBPD_CORE_PDO_SRC_FIXED_MAX_CURRENT 3
#define USBPD_CORE_PDO_SNK_FIXED_MAX_CURRENT 1500

/* USER CODE END Exported_Define */

/* Exported constants --------------------------------------------------------*/

/* USER CODE BEGIN constants */

/* USER CODE END constants */

/* Exported macro ------------------------------------------------------------*/

/* USER CODE BEGIN macro */

/* USER CODE END macro */

/* Exported variables --------------------------------------------------------*/

/* USER CODE BEGIN variables */
/* USER CODE END variables */

#ifndef __USBPD_PWR_IF_C
extern uint32_t PORT0_PDO_ListSRC[USBPD_MAX_NB_PDO];
extern uint32_t PORT0_PDO_ListSNK[USBPD_MAX_NB_PDO];
#else
/* Definition of Source PDO for Port 0 */
uint32_t PORT0_PDO_ListSRC[USBPD_MAX_NB_PDO] =
{
  /* PDO 1 */ (0x00000000U),

  /* PDO 2 */ (0x00000000U),

  /* PDO 3 */ (0x00000000U),

  /* PDO 4 */ (0x00000000U),

  /* PDO 5 */ (0x00000000U),

  /* PDO 6 */ (0x00000000U),

  /* PDO 7 */ (0x00000000U),

};

/* Definition of Sink PDO for Port 0 */
uint32_t PORT0_PDO_ListSNK[USBPD_MAX_NB_PDO] =
{
  /* PDO 1 */
  (
    USBPD_PDO_TYPE_FIXED                 | /* Fixed supply PDO            */

    USBPD_PDO_SNK_FIXED_SET_VOLTAGE(5000U)         | /* Voltage in mV               */
    USBPD_PDO_SNK_FIXED_SET_OP_CURRENT(3000U)     | /* Operating current in  mA            */

    /* Common definitions applicable to all PDOs, defined only in PDO 1 */
    USBPD_PDO_SNK_FIXED_FRS_NOT_SUPPORTED          | /* Fast Role Swap				 */
    USBPD_PDO_SNK_FIXED_DRD_NOT_SUPPORTED          | /* Dual-Role Data              */
    USBPD_PDO_SNK_FIXED_USBCOMM_NOT_SUPPORTED      | /* USB Communications          */
    USBPD_PDO_SNK_FIXED_EXT_POWER_AVAILABLE    | /* External Power              */
    USBPD_PDO_SNK_FIXED_HIGHERCAPAB_SUPPORTED   | /* Higher Capability           */
    USBPD_PDO_SNK_FIXED_DRP_NOT_SUPPORTED            /* Dual-Role Power             */
  ),

  /* PDO 2 */
  (
    USBPD_PDO_TYPE_FIXED                        | /* Fixed supply                */

    USBPD_PDO_SNK_FIXED_SET_VOLTAGE(9000U)         | /* Voltage in mV               */
    USBPD_PDO_SNK_FIXED_SET_OP_CURRENT(3000U)       /* Operating current in  mA            */
  ),

  /* PDO 3 */
  (
    USBPD_PDO_TYPE_FIXED                        | /* Fixed supply                */

    USBPD_PDO_SNK_FIXED_SET_VOLTAGE(15000U)         | /* Voltage in mV               */
    USBPD_PDO_SNK_FIXED_SET_OP_CURRENT(3000U)       /* Operating current in  mA            */
  ),

  /* PDO 4 */
  (
    USBPD_PDO_TYPE_FIXED                        | /* Fixed supply                */

    USBPD_PDO_SNK_FIXED_SET_VOLTAGE(20000U)         | /* Voltage in mV               */
    USBPD_PDO_SNK_FIXED_SET_OP_CURRENT(5000U)       /* Operating current in  mA            */
  ),

  /* PDO 5 */
  (
    USBPD_PDO_TYPE_VARIABLE                        | /* Variable Supply                */

    USBPD_PDO_SNK_VARIABLE_SET_OP_CURRENT(5000U)         | /* Max Current mA           */
    USBPD_PDO_SNK_VARIABLE_SET_MAX_VOLTAGE(21000U)     | /* Max Voltage mV           */
    USBPD_PDO_SNK_VARIABLE_SET_MIN_VOLTAGE(3300U)            /* Min Voltage mV           */
  ),

  /* PDO 6 */
  (
    USBPD_PDO_TYPE_APDO                             | /* APDO                        */

    USBPD_PDO_SNK_APDO_SET_MIN_VOLTAGE(15000U)       | /* Min voltage in mV           */
    USBPD_PDO_SNK_APDO_SET_MAX_VOLTAGE(28000U)       | /* Max voltage in mV           */
    USBPD_PDO_SNK_APDO_SET_MAX_CURRENT(5000U)        /* Max current in mA           */
  ),

  /* PDO 7 */
  (
    USBPD_PDO_TYPE_BATTERY                        | /* Battery                */

    USBPD_PDO_SNK_BATTERY_SET_OP_POWER(30000U)         | /* Power mW               */
    USBPD_PDO_SNK_BATTERY_SET_MAX_VOLTAGE(21000U)     | /* Max Voltage mV           */
    USBPD_PDO_SNK_BATTERY_SET_MIN_VOLTAGE(3300U)            /* Min Voltage mV           */
  ),
};

#endif

/* Exported functions --------------------------------------------------------*/

/* USER CODE BEGIN functions */

/* USER CODE END functions */

#ifdef __cplusplus
}
#endif

#endif /* __USBPD_PDO_DEF_H */
